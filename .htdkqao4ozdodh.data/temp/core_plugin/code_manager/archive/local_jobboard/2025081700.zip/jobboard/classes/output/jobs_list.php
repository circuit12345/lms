<?php
namespace local_jobboard\output;

defined('MOODLE_INTERNAL') || die();

use renderable;
use templatable;
use renderer_base;
use moodle_url;

class jobs_list implements renderable, templatable {
    /** @var array */
    protected $jobs = [];
    /** @var bool */
    protected $canapply;

    public function __construct(array $jobs, bool $canapply = true) {
        $this->jobs = $jobs;
        $this->canapply = $canapply;
    }

    public function export_for_template(renderer_base $output) {
        $cards = [];
        foreach ($this->jobs as $j) {
            $statuslabel = $j->published && (empty($j->applydeadline) || $j->applydeadline > time()) ?
                get_string('open', 'local_jobboard') : get_string('closed', 'local_jobboard');

            $tags = [];
            if (!empty($j->tags)) {
                foreach (array_filter(array_map('trim', explode(',', $j->tags))) as $t) {
                    $tags[] = $t;
                }
            }
            $cards[] = [
                'id' => $j->id,
                'title' => format_string($j->title),
                'summary' => format_text($j->summary, FORMAT_HTML),
                'location' => s($j->location ?? ''),
                'jobtype' => s($j->jobtype ?? ''),
                'posted_relative' => userdate($j->timecreated, get_string('strftimedatefullshort')),
                'status_label' => $statuslabel,
                'status_class' => $statuslabel === get_string('open', 'local_jobboard') ? 'open' : 'closed',
                'tags' => $tags,
                'view_url' => (new moodle_url('/local/jobboard/view.php', ['id' => $j->id]))->out(false),
                'canapply' => $this->canapply && $statuslabel === get_string('open', 'local_jobboard'),
            ];
        }
        return [
            'jobs' => $cards,
        ];
    }
}
