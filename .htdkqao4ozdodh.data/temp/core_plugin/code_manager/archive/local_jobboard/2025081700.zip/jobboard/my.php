<?php
require('../../config.php');

require_login();
$context = context_system::instance();
require_capability('local/jobboard:apply', $context);

$PAGE->set_url(new moodle_url('/local/jobboard/my.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('nav_myapps', 'local_jobboard'));
$PAGE->set_heading(get_string('nav_myapps', 'local_jobboard'));

$sql = "SELECT a.*, j.title AS jobtitle
          FROM {jobboard_applications} a
          JOIN {jobboard_jobs} j ON j.id = a.jobid
         WHERE a.userid = :uid
      ORDER BY a.timecreated DESC";
$apps = $DB->get_records_sql($sql, ['uid' => $USER->id]);

echo $OUTPUT->header();

if ($apps) {
    echo html_writer::start_tag('table', ['class' => 'generaltable']);
    echo html_writer::start_tag('thead');
    echo html_writer::tag('tr',
        html_writer::tag('th', get_string('title', 'local_jobboard')) .
        html_writer::tag('th', get_string('status', 'local_jobboard')) .
        html_writer::tag('th', get_string('time'))
    );
    echo html_writer::end_tag('thead');
    echo html_writer::start_tag('tbody');
    foreach ($apps as $r) {
        echo html_writer::tag('tr',
            html_writer::tag('td', format_string($r->jobtitle)) .
            html_writer::tag('td', s($r->status)) .
            html_writer::tag('td', userdate($r->timecreated))
        );
    }
    echo html_writer::end_tag('tbody');
    echo html_writer::end_tag('table');
} else {
    echo $OUTPUT->notification(get_string('noapps', 'local_jobboard'), \core\output\notification::NOTIFY_INFO);
}

echo $OUTPUT->footer();
