<?php
defined('MOODLE_INTERNAL') || die();

function local_jobboard_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options=array()) {
    require_login();
    if ($context->contextlevel != CONTEXT_SYSTEM) {
        return false;
    }
    if ($filearea !== 'resume') {
        return false;
    }
    $itemid = array_shift($args);
    $fs = get_file_storage();
    $relativepath = implode('/', $args);
    $fullpath = "/{$context->id}/local_jobboard/$filearea/$itemid/$relativepath";
    if (!$file = $fs->get_file_by_hash(sha1($fullpath))) {
        return false;
    }
    // Access control: owner or staff.
    global $USER, $DB;
    $app = $DB->get_record('jobboard_applications', ['id' => $itemid], '*', MUST_EXIST);
    $systemcontext = context_system::instance();
    if ($USER->id != $app->userid && !has_any_capability(['local/jobboard:viewapplications','local/jobboard:managejobs'], $systemcontext)) {
        send_file_not_found();
    }
    send_stored_file($file, 0, 0, true, $options);
}

function local_jobboard_extend_navigation(global_navigation $nav) {
    $node = navigation_node::create(
        get_string('pluginname', 'local_jobboard'),
        new moodle_url('/local/jobboard/index.php'),
        navigation_node::TYPE_CUSTOM,
        null,
        'local_jobboard',
        new pix_icon('i/navigationitem', '')
    );
    $nav->add_node($node);
}
