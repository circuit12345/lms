<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'theme_neo_remui';
$plugin->version   = 2025081700; // YYYYMMDDHH.
$plugin->requires  = 2024042200; // Moodle 4.4 (adjust if on earlier).
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0.0';
