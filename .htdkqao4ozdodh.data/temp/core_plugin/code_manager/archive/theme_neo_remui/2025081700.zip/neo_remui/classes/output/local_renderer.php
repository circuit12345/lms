<?php
namespace theme_neo_remui\output;

defined('MOODLE_INTERNAL') || die();

class local_renderer {
    public static function get_user_courses_context(\stdClass $user) : array {
        $courses = enrol_get_my_courses(['id', 'shortname', 'fullname'], 'fullname ASC');
        $items = [];
        foreach ($courses as $c) {
            $progress = null;
            try {
                if (class_exists('\core_completion\progress')) {
                    $p = \core_completion\progress::get_course_progress_percentage($c, $user->id);
                    if (is_numeric($p)) {
                        $progress = round($p);
                    }
                }
            } catch (\Throwable $e) {}

            $items[] = [
                'fullname' => format_string($c->fullname),
                'shortname' => format_string($c->shortname),
                'url' => (new \moodle_url('/course/view.php', ['id' => $c->id]))->out(false),
                'progress' => $progress
            ];
        }
        return $items;
    }
}
