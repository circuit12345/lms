<?php
defined('MOODLE_INTERNAL') || die();

$progress = null;
if (class_exists('\core_completion\progress')) {
    $p = \core_completion\progress::get_course_progress_percentage($COURSE, $USER->id);
    if (is_numeric($p)) {
        $progress = round($p);
    }
}

$context = [
    'output' => $OUTPUT,
    'course' => $COURSE,
    'progress' => $progress,
    'sidepreblocks' => $OUTPUT->blocks('side-pre'),
];

echo $OUTPUT->render_from_template('theme_neo_remui/course', $context);
