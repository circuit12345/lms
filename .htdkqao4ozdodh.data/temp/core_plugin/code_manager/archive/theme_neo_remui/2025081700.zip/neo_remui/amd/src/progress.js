define(['core/log'], function(Log) {
  return {
    init: function() {
      try {
        document.querySelectorAll('.progress-bar').forEach(function(el) {
          el.style.transition = 'width .35s ease';
        });
      } catch (e) {
        Log.debug('neo_remui progress init failed', e);
      }
    }
  };
});
