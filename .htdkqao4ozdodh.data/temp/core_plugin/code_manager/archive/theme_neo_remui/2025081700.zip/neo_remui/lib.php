<?php
defined('MOODLE_INTERNAL') || die();

function theme_neo_remui_get_main_scss_content($theme) {
    $preset = !empty($theme->settings->preset) ? $theme->settings->preset : (get_config('theme_neo_remui', 'preset') ?? 'modern');
    $brand  = !empty($theme->settings->brandcolor) ? $theme->settings->brandcolor : (get_config('theme_neo_remui', 'brandcolor') ?? '#3b82f6');

    $scss = ":root{--brand: {$brand};}\n";

    $file = __DIR__ . '/scss/neo.scss';
    if ($preset === 'modern' && file_exists(__DIR__ . '/scss/preset/modern.scss')) {
        $file = __DIR__ . '/scss/preset/modern.scss';
    }

    if (file_exists($file)) {
        $scss .= file_get_contents($file);
    } else {
        // Minimal fallback so the page never renders without any CSS.
        $scss .= "body{font-family:system-ui,sans-serif}.card{background:#fff;border-radius:12px;box-shadow:0 8px 28px rgba(2,6,23,.06)}";
    }

    return $scss;
}
