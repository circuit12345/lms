<?php
defined('MOODLE_INTERNAL') || die();

$context = [
    'sitename' => format_string($SITE->shortname, true, ['context' => \context_system::instance()]),
    'output' => $OUTPUT,
    'sidepreblocks' => $OUTPUT->blocks('side-pre'),
    'hasblocks' => strpos($OUTPUT->blocks('side-pre'), 'data-block') !== false,
    'darkmode' => (bool) get_config('theme_neo_remui', 'darkmode'),
    'herotitle' => (string) (get_config('theme_neo_remui', 'herotitle') ?? 'Learn. Build. Grow.'),
    'isloggedin' => isloggedin() && !isguestuser(),
    'wwwroot' => (new \moodle_url('/'))->out(false),
];

echo $OUTPUT->render_from_template('theme_neo_remui/default', $context);
