<?php
$string['pluginname'] = 'Neo RemUI';
$string['configtitle'] = 'Neo RemUI';
$string['preset'] = 'Style preset';
$string['preset_desc'] = 'Choose a visual style preset for the theme.';
$string['brandcolor'] = 'Brand color';
$string['brandcolor_desc'] = 'Primary brand accent used across the UI.';
$string['darkmode'] = 'Enable dark mode toggle';
$string['darkmode_desc'] = 'Allow users to switch to dark mode.';
$string['herotitle'] = 'Homepage title';
$string['herotitle_desc'] = 'Title shown in the frontpage hero section.';
