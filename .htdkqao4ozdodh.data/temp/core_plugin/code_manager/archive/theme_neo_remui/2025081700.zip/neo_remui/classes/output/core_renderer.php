<?php
namespace theme_neo_remui\output;

defined('MOODLE_INTERNAL') || die();

class core_renderer extends \core_renderer {
    // Stub to avoid fatal if a template calls firstview_fakeblocks().
    public function firstview_fakeblocks() {
        // Return real side-pre blocks, or empty string if you prefer.
        return $this->blocks('side-pre');
    }
}
