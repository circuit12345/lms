<?php
defined('MOODLE_INTERNAL') || die();

function theme_neo_remui_get_main_scss_content($theme) {
    $scss = '';

    $preset = 'default';
    if (!empty($theme->settings->preset)) {
        $preset = $theme->settings->preset;
    }

    $brand = !empty($theme->settings->brandcolor) ? $theme->settings->brandcolor : '#3b82f6';
    $dark = !empty($theme->settings->darkmode) ? 'true' : 'false';

    // Inject CSS variables first so SCSS can use them if needed.
    $scss .= ":root{--brand: {$brand};}\n";

    if ($preset === 'modern' && file_exists(__DIR__.'/scss/preset/modern.scss')) {
        $scss .= file_get_contents(__DIR__.'/scss/preset/modern.scss');
    } else {
        $scss .= file_get_contents(__DIR__.'/scss/neo.scss');
    }

    // Optional: expose dark mode preference as data attribute toggler via body class.
    if ($dark === 'true') {
        $scss .= "\n/* Dark mode enabled */\n";
    }

    return $scss;
}
