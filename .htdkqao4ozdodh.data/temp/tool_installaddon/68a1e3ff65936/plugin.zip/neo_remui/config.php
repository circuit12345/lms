<?php
defined('MOODLE_INTERNAL') || die();

$THEME->name = 'neo_remui';
$THEME->parents = ['boost'];

$THEME->sheets = []; // Use SCSS, not old CSS sheets.

$THEME->scss = function($theme) {
    require_once(__DIR__.'/lib.php');
    return theme_neo_remui_get_main_scss_content($theme);
};

$THEME->editor_scss = ['editor'];
$THEME->rendererfactory = 'theme_overridden_renderer_factory';
$THEME->iconsystem = \core\output\icon_system::FONTAWESOME;

$THEME->layouts = [
    'base' => [
        'file' => 'default.php',
        'regions' => ['side-pre'],
        'defaultregion' => 'side-pre',
    ],
    'standard' => [
        'file' => 'default.php',
        'regions' => ['side-pre'],
        'defaultregion' => 'side-pre',
    ],
    'course' => [
        'file' => 'columns2.php',
        'regions' => ['side-pre'],
        'defaultregion' => 'side-pre',
        'options' => ['nonavbar' => false],
    ],
    'mydashboard' => [
        'file' => 'default.php',
        'regions' => ['side-pre'],
        'defaultregion' => 'side-pre',
    ],
    'login' => [
        'file' => 'default.php',
        'regions' => [],
    ],
];

$THEME->enable_dock = false;
