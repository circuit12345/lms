<?php
namespace theme_neo_remui\output;

defined('MOODLE_INTERNAL') || die();

class core_renderer extends \core_renderer {
    public function full_header() {
        global $COURSE, $USER;

        // Call parent to set up page header.
        $header = parent::full_header();

        // Example: You can enrich $this->page context with course image URL or progress.
        if (!empty($COURSE) && $COURSE->id > 1) {
            try {
                if (class_exists('\core_course\external\course_summary_exporter')) {
                    $imgurl = \core_course\external\course_summary_exporter::get_course_image($COURSE);
                    $this->page->set_otherheadertitle($COURSE->fullname);
                    // If you have templates reading from JS or additional context, assign via page->requires or body classes.
                    if ($imgurl) {
                        $this->page->add_body_class('has-course-image');
                    }
                }
            } catch (\Throwable $e) {
                // Ignore if not available.
            }
        }

        return $header;
    }
}
