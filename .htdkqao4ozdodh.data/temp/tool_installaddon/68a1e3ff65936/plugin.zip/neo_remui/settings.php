<?php
defined('MOODLE_INTERNAL') || die();

$settings = null;

if ($hassiteconfig) {
    $settings = new theme_boost_admin_settingspage_tabs('themesettingneo_remui', get_string('configtitle', 'theme_neo_remui'));

    // Preset selector.
    $name = 'theme_neo_remui/preset';
    $title = get_string('preset', 'theme_neo_remui');
    $desc = get_string('preset_desc', 'theme_neo_remui');
    $choices = ['modern' => 'Modern', 'default' => 'Default'];
    $setting = new admin_setting_configselect($name, $title, $desc, 'modern', $choices);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settings->add($setting);

    // Brand color.
    $name = 'theme_neo_remui/brandcolor';
    $title = get_string('brandcolor', 'theme_neo_remui');
    $desc = get_string('brandcolor_desc', 'theme_neo_remui');
    $setting = new admin_setting_configcolourpicker($name, $title, $desc, '#3b82f6');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settings->add($setting);

    // Dark mode.
    $name = 'theme_neo_remui/darkmode';
    $title = get_string('darkmode', 'theme_neo_remui');
    $desc = get_string('darkmode_desc', 'theme_neo_remui');
    $setting = new admin_setting_configcheckbox($name, $title, $desc, 1);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settings->add($setting);

    // Hero title.
    $name = 'theme_neo_remui/herotitle';
    $title = get_string('herotitle', 'theme_neo_remui');
    $desc = get_string('herotitle_desc', 'theme_neo_remui');
    $setting = new admin_setting_configtext($name, $title, $desc, 'Learn. Build. Grow.');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $settings->add($setting);

    $ADMIN->add('themes', $settings);
}
