<?php
defined('MOODLE_INTERNAL') || die();

$progress = null;
try {
    if (class_exists('\core_completion\progress')) {
        $progress = \core_completion\progress::get_course_progress_percentage($COURSE, $USER->id);
        if (is_numeric($progress)) {
            $progress = round($progress);
        } else {
            $progress = null;
        }
    }
} catch (\Throwable $e) {
    $progress = null;
}

$context = [
    'output' => $OUTPUT,
    'course' => $COURSE,
    'progress' => $progress,
    'sidepreblocks' => $OUTPUT->blocks('side-pre'),
];

echo $OUTPUT->render_from_template('theme_neo_remui/course', $context);
