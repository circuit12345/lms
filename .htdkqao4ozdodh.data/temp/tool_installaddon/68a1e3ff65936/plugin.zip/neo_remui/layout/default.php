<?php
defined('MOODLE_INTERNAL') || die();

$context = [
    'sitename' => format_string($SITE->shortname, true, ['context' => \context_system::instance()]),
    'output' => $OUTPUT,
    'sidepreblocks' => $OUTPUT->blocks('side-pre'),
    'hasblocks' => strpos($OUTPUT->blocks('side-pre'), 'data-block') !== false,
    'darkmode' => !empty(theme_get_setting('darkmode')),
    'herotitle' => theme_get_setting('herotitle'),
    'isloggedin' => isloggedin() && !isguestuser(),
];

echo $OUTPUT->render_from_template('theme_neo_remui/default', $context);
